from django.urls import path, include
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    path('hello/', views.say_hello, name='index'),
    path('hello1/', views.html_cv, name='htmlCV'),
    path('hello2/', views.css_cv, name='cssCV'),
]
#,
#, name='index'